import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TopicCard } from "./TopicCard";
import { allTags, categories, topics } from "@/data/topics";

export function SearchFilter() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [tag, setTag] = useState<string | null>(null);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return topics.filter((t) => {
      const matchesQuery =
        !q || t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q);
      const matchesCategory = category === "all" || t.category === category;
      const matchesTag = !tag || t.tags.includes(tag);
      return matchesQuery && matchesCategory && matchesTag;
    });
  }, [query, category, tag]);

  return (
    <section id="browse" className="border-b border-border">
      <div className="container-page py-20 md:py-28">
        <h2 className="font-display text-2xl font-semibold md:text-3xl">Browse the archive</h2>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">
          Narrow by keyword, category, or tag to find the discussion closest to the decision you are
          making.
        </p>

        <div className="mt-10 flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <label htmlFor="topic-search" className="sr-only">
              Search topics by keyword
            </label>
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="topic-search"
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search topics"
              className="h-11 rounded-sm border-border bg-card pl-9"
            />
          </div>
          <div className="sm:w-56">
            <label htmlFor="category-filter" className="sr-only">
              Filter by category
            </label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger
                id="category-filter"
                className="h-11 w-full rounded-sm border-border bg-card"
              >
                <SelectValue placeholder="All categories" />
              </SelectTrigger>
              <SelectContent className="rounded-sm">
                <SelectItem value="all">All categories</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-2" role="group" aria-label="Tag filter">
          {allTags.map((t) => {
            const active = tag === t;
            return (
              <button
                key={t}
                type="button"
                aria-pressed={active}
                onClick={() => setTag(active ? null : t)}
                className={`rounded-sm border px-2.5 py-1 text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                  active
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:border-border-strong hover:text-foreground"
                }`}
              >
                #{t}
              </button>
            );
          })}
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {results.map((topic) => (
            <TopicCard key={topic.id} topic={topic} />
          ))}
        </div>
        {results.length === 0 && (
          <p className="mt-12 text-sm text-muted-foreground">
            No topics match those filters yet. Try a broader search.
          </p>
        )}
      </div>
    </section>
  );
}
