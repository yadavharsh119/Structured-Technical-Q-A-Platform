import { MessagesSquare } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Topic } from "@/data/topics";

export function TopicCard({ topic }: { topic: Topic }) {
  return (
    <article className="group flex h-full flex-col rounded-sm border border-border bg-card p-6 transition-colors hover:border-primary/50">
      <Badge
        variant="outline"
        className="w-fit rounded-sm border-primary/40 bg-transparent text-[0.65rem] uppercase tracking-widest text-primary"
      >
        {topic.category}
      </Badge>
      <h3 className="mt-4 font-display text-lg font-medium leading-snug">{topic.title}</h3>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
        {topic.description}
      </p>
      <ul className="mt-5 flex flex-wrap gap-2">
        {topic.tags.map((tag) => (
          <li
            key={tag}
            className="rounded-sm bg-secondary px-2 py-0.5 text-xs text-muted-foreground"
          >
            #{tag}
          </li>
        ))}
      </ul>
      <div className="mt-5 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground">
        <MessagesSquare aria-hidden="true" className="size-3.5" />
        {topic.perspectives} perspectives
      </div>
    </article>
  );
}
