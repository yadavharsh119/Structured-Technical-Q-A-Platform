import { Skeleton } from "@/components/ui/skeleton";

export function TopicCardSkeleton() {
  return (
    <div className="rounded-sm border border-border bg-card p-6">
      <Skeleton className="h-5 w-20 rounded-sm" />
      <Skeleton className="mt-4 h-6 w-4/5 rounded-sm" />
      <Skeleton className="mt-3 h-4 w-full rounded-sm" />
      <Skeleton className="mt-2 h-4 w-11/12 rounded-sm" />
      <div className="mt-5 flex gap-2">
        <Skeleton className="h-5 w-14 rounded-sm" />
        <Skeleton className="h-5 w-16 rounded-sm" />
        <Skeleton className="h-5 w-12 rounded-sm" />
      </div>
      <Skeleton className="mt-6 h-4 w-28 rounded-sm" />
    </div>
  );
}
