const columns = [
  { heading: "Platform", links: ["About", "Topics", "Categories"] },
  { heading: "Legal", links: ["Terms of Service", "Privacy Policy", "GDPR Information"] },
];

export function Footer() {
  return (
    <footer id="about" className="bg-background">
      <div className="container-page py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <p className="font-display text-base font-semibold">
              Stack<span className="text-primary">Rationale</span>
            </p>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted-foreground">
              A technical Q&amp;A platform for the how, what and why of choosing a tech stack —
              structured around competing perspectives rather than a single accepted answer.
            </p>
          </div>
          {columns.map((col) => (
            <nav key={col.heading} aria-label={col.heading}>
              <h2 className="text-xs uppercase tracking-widest text-muted-foreground">
                {col.heading}
              </h2>
              <ul className="mt-4 space-y-2">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#top"
                      className="text-sm text-foreground/80 transition-colors hover:text-primary"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>
        <div className="mt-12 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} StackRationale. All rights reserved.</p>
          <p>Version 1.0</p>
        </div>
      </div>
    </footer>
  );
}
