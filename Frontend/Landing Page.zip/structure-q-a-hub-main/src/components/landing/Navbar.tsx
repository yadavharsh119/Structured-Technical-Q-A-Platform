import { useState } from "react";
import { Menu, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const links = [
  { label: "Topics", href: "#topics" },
  { label: "Categories", href: "#browse" },
  { label: "About", href: "#about" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur">
      <div className="container-page flex h-16 items-center gap-6">
        <a href="#top" className="font-display text-base font-semibold tracking-tight">
          Stack<span className="text-primary">Rationale</span>
        </a>

        <nav aria-label="Main" className="hidden items-center gap-6 md:flex">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="ml-auto hidden w-64 lg:block">
          <label htmlFor="global-search" className="sr-only">
            Search topics
          </label>
          <div className="relative">
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="global-search"
              type="search"
              placeholder="Search the archive"
              className="h-9 rounded-sm border-border bg-card pl-9 text-sm"
            />
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2 lg:ml-0">
          <Button variant="ghost" size="sm" className="hidden rounded-sm sm:inline-flex">
            Login
          </Button>
          <Button
            size="sm"
            className="hidden rounded-sm bg-primary text-primary-foreground hover:bg-primary-soft sm:inline-flex"
          >
            Register
          </Button>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 border-border bg-card">
              <SheetTitle className="font-display text-base">Menu</SheetTitle>
              <nav aria-label="Mobile" className="mt-6 flex flex-col gap-1">
                {links.map((l) => (
                  <a
                    key={l.label}
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="rounded-sm px-2 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                  >
                    {l.label}
                  </a>
                ))}
              </nav>
              <div className="mt-6 flex flex-col gap-2">
                <Button variant="outline" className="rounded-sm">
                  Login
                </Button>
                <Button className="rounded-sm bg-primary text-primary-foreground hover:bg-primary-soft">
                  Register
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
