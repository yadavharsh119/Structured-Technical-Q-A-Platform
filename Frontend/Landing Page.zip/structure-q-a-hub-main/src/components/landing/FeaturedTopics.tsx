import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { TopicCard } from "./TopicCard";
import { TopicCardSkeleton } from "./TopicCardSkeleton";
import { topics } from "@/data/topics";

export function FeaturedTopics() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(t);
  }, []);

  return (
    <section id="topics" className="border-b border-border">
      <div className="container-page py-20 md:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-xl">
            <h2 className="font-display text-2xl font-semibold md:text-3xl">Featured topics</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Long-running questions where the answer depends on your constraints — each one holds
              multiple documented perspectives.
            </p>
          </div>
          <Button variant="outline" className="rounded-sm border-border-strong bg-transparent">
            View all topics
          </Button>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => <TopicCardSkeleton key={i} />)
            : topics.map((topic) => <TopicCard key={topic.id} topic={topic} />)}
        </div>
      </div>
    </section>
  );
}
