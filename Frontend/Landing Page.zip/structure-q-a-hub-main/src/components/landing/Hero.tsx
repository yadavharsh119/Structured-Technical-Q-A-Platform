import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section id="top" className="relative border-b border-border">
      <div className="container-page py-24 md:py-36">
        <p className="text-xs uppercase tracking-[0.25em] text-primary">
          Technical Q&amp;A — reasoned, not ranked
        </p>
        <h1 className="mt-6 max-w-3xl font-display text-4xl font-semibold leading-[1.05] md:text-6xl">
          Every stack decision, argued from more than one side.
        </h1>
        <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
          StackRationale collects the how, what and why behind choosing a technology: the
          trade-offs, the failure modes, and the context that made an answer right. Each topic keeps
          competing perspectives side by side instead of collapsing them into one accepted reply.
        </p>
        <div className="mt-10 flex flex-wrap items-center gap-3">
          <Button
            size="lg"
            className="rounded-sm bg-primary text-primary-foreground hover:bg-primary-soft"
          >
            Get started
            <ArrowRight className="ml-2 size-4" />
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="rounded-sm border-border-strong bg-transparent"
          >
            <a href="#topics">Browse topics</a>
          </Button>
        </div>
        <dl className="mt-16 grid max-w-lg grid-cols-3 gap-8 border-t border-border pt-8">
          {[
            ["1.2k", "Topics"],
            ["8.4k", "Perspectives"],
            ["24", "Categories"],
          ].map(([value, label]) => (
            <div key={label}>
              <dt className="text-xs uppercase tracking-widest text-muted-foreground">{label}</dt>
              <dd className="mt-1 font-display text-2xl">{value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
