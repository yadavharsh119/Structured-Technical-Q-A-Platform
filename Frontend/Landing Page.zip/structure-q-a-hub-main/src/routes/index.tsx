import { createFileRoute } from "@tanstack/react-router";
import { ThemeProvider } from "@/components/theme-provider";
import { Navbar } from "@/components/landing/Navbar";
import { Hero } from "@/components/landing/Hero";
import { FeaturedTopics } from "@/components/landing/FeaturedTopics";
import { SearchFilter } from "@/components/landing/SearchFilter";
import { Footer } from "@/components/landing/Footer";

const title = "StackRationale — Technical Q&A on Choosing Your Tech Stack";
const description =
  "Compare perspectives on the how, what and why of tech stack decisions: frameworks, databases, infrastructure and architecture trade-offs.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ThemeProvider defaultTheme="dark">
      <a
        href="#topics"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-sm focus:bg-primary focus:px-3 focus:py-2 focus:text-sm focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <Navbar />
      <main>
        <Hero />
        <FeaturedTopics />
        <SearchFilter />
      </main>
      <Footer />
    </ThemeProvider>
  );
}
