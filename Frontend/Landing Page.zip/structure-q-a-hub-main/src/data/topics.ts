export type Topic = {
  id: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  perspectives: number;
};

export const categories = [
  "Frontend",
  "Backend",
  "Databases",
  "Infrastructure",
  "Architecture",
  "Tooling",
] as const;

export const topics: Topic[] = [
  {
    id: "rsc-vs-spa",
    title: "Server components or a classic SPA?",
    description:
      "When streaming server rendering actually pays off, and when it just moves complexity from the client to your infrastructure bill.",
    category: "Frontend",
    tags: ["react", "ssr", "rendering"],
    perspectives: 42,
  },
  {
    id: "postgres-vs-mongo",
    title: "Why teams keep returning to Postgres",
    description:
      "Document stores promise flexible schemas. Engineers explain which access patterns justify that trade and which quietly regret it.",
    category: "Databases",
    tags: ["postgres", "mongodb", "modeling"],
    perspectives: 68,
  },
  {
    id: "monolith-first",
    title: "Monolith first, services later",
    description:
      "How to decide the moment a single deployable stops serving you, with concrete signals instead of team-size folklore.",
    category: "Architecture",
    tags: ["microservices", "scaling", "ddd"],
    perspectives: 91,
  },
  {
    id: "edge-runtimes",
    title: "What edge runtimes are actually good at",
    description:
      "Cold starts, regional data, and the Node APIs you give up. A practical map of workloads that belong at the edge.",
    category: "Infrastructure",
    tags: ["edge", "workers", "latency"],
    perspectives: 27,
  },
  {
    id: "typed-apis",
    title: "tRPC, GraphQL, or plain REST",
    description:
      "Choosing an API contract by who consumes it — internal product teams, third parties, or a mobile client you cannot force to upgrade.",
    category: "Backend",
    tags: ["graphql", "trpc", "rest"],
    perspectives: 54,
  },
  {
    id: "build-tooling",
    title: "Is your build tool the bottleneck?",
    description:
      "Measuring before migrating: where Vite, Turbopack, and Bun genuinely differ once your repo passes a hundred thousand lines.",
    category: "Tooling",
    tags: ["vite", "bundlers", "monorepo"],
    perspectives: 33,
  },
];

export const allTags = Array.from(new Set(topics.flatMap((t) => t.tags))).sort();
