# Dark Landing Page — Tech Stack Q&A Platform

A single dark, minimal, editorial landing page for a platform where developers debate the how/what/why of choosing a tech stack. Static demo content, no backend yet.

## Visual direction

- Palette: Noir & Gold — near-black background (#0d0d0d), raised surfaces (#1a1a1a), gold accent (#c9a84c) with a lighter gold (#f0d78c) for hover/highlights. Gold is used sparingly: badges, active states, CTA, thin rules.
- Type: Space Grotesk for headings, DM Sans for body, loaded via a `<link>` in the root head.
- Restrained motion, hairline borders, generous whitespace, small radius, no gradients or glows.

## Sections

1. Navbar — wordmark, links (Topics, Categories, About), compact global search, Login (ghost) + Register (gold) buttons; mobile sheet menu.
2. Hero — headline about deciding which stack to use and why, one-paragraph overview, two CTAs (Get Started, Browse Topics).
3. Featured Topics — section header plus a grid of topic cards: title, description, category badge, tags, perspective count. "View All Topics" button. Skeleton loading state included and briefly shown on mount so the real skeleton component is used.
4. Search & Filter — search input, category dropdown, tag filter chips; filters the demo topics live on the client.
5. Footer — About, Topics, Categories, Terms of Service, Privacy Policy, GDPR Information, plus "Version 1.0" and copyright.

## Global UI

- Responsive container/layout wrapper shared by all sections.
- Accessibility: semantic landmarks, single H1, skip-to-content link, aria-labels on search/filter controls, visible focus rings.
- Theme provider defaulting to dark (`.dark` on `<html>`), so the design system tokens are honored and light mode stays possible later.

## Technical notes

- Rewrite `src/routes/index.tsx` as the landing page with its own `head()` (unique title, description, og/twitter tags).
- Replace the default token values in `src/styles.css` with the Noir & Gold scale in oklch, add `--font-display`/`--font-sans` theme tokens; no hardcoded color utilities in components.
- New components under `src/components/landing/`: `Navbar`, `Hero`, `FeaturedTopics`, `TopicCard`, `TopicCardSkeleton`, `SearchFilter`, `Footer`, plus `src/components/theme-provider.tsx`.
- Demo topics live in `src/data/topics.ts` (typed array) so swapping in a real data source later is a one-file change.
- Uses existing shadcn primitives (button, input, badge, select, skeleton, sheet); any missing primitive gets added.
- Nav links point to in-page sections for now; separate Topics/Categories/About routes are not part of this pass.
